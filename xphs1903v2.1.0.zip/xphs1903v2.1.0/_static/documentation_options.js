const DOCUMENTATION_OPTIONS = {
    VERSION: '2.1.0+',
    LANGUAGE: 'fr',
    COLLAPSE_INDEX: false,
    BUILDER: 'singlehtml',
    FILE_SUFFIX: '.html',
    LINK_SUFFIX: '.html',
    HAS_SOURCE: true,
    SOURCELINK_SUFFIX: '.txt',
    NAVIGATION_WITH_KEYS: false,
    SHOW_SEARCH_SUMMARY: true,
    ENABLE_SEARCH_SHORTCUTS: true,
};